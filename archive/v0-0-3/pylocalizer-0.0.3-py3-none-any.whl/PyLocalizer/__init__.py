"""
# PyLocalizer *by MF366*
https://pypi.org/project/PyLocalizer/
"""

from . import internal
