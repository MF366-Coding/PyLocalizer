"""
NCapybaraLib; By NorbCodes.

A small library with a bunch of functions and thingies I made for fun.

https://pypi.org/project/NCapybaraLib/
"""

from . import internal

from .EntryFormatting import *

from .WebLocalization import *
