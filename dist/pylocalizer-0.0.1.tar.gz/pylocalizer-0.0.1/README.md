# PyLocalizer
A Python module that serves as a straight-forward and simple way to add locales to your programs.
